<?php
/**
 * The template for displaying the footer.
 *
 * @link https://livecomposerplugin.com/themes/
 *
 * @package LC Blank
 */

?>

<?php

if ( function_exists( 'dslc_hf_get_footer' ) ) {
	echo dslc_hf_get_footer();
}

?>

<?php wp_footer(); ?>

</body>
</html>
